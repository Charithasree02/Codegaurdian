declare const chrome: any;

import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import { AnalysisType, TestCase, Message } from './src/types';
import { PROMPTS } from './src/constants';

// The API key is injected by the Vite build process.
const apiKey = process.env.API_KEY;
if (!apiKey) {
  console.error("API_KEY is not defined. Please set VITE_API_KEY in your .env file.");
}
const ai = new GoogleGenAI({ apiKey: apiKey || "" });

// --- CONTEXT MENU SETUP ---
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: "code-guardian-analyze",
    title: "Analyze with Code Guardian",
    contexts: ["selection"],
  });
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === "code-guardian-analyze" && info.selectionText && tab?.id) {
    // Send a message to the content script to open the side panel
    chrome.tabs.sendMessage(tab.id, {
      type: 'TOGGLE_PANEL',
      payload: { code: info.selectionText },
    });
  }
});

// --- API LOGIC ---

const parseTestCases = (jsonString: string): TestCase[] => {
  let cleanJsonString = jsonString.trim();
  const fenceRegex = /^```(?:json)?\s*\n?(.*?)\n?\s*```$/s;
  const match = cleanJsonString.match(fenceRegex);
  if (match && match[1]) {
    cleanJsonString = match[1].trim();
  }

  try {
    const data = JSON.parse(cleanJsonString);
    if (Array.isArray(data)) {
      return data.filter(item => typeof item === 'object' && item !== null && 'input' in item && 'expectedOutput' in item);
    }
    return [{ input: 'Parsing Error', expectedOutput: 'Received valid JSON, but it was not an array of test cases.', description: cleanJsonString }];
  } catch (error) {
    console.error("Failed to parse JSON response:", error);
    return [{ input: 'Error', expectedOutput: 'Failed to parse JSON from AI.', description: jsonString }];
  }
};

const analyzeCode = async (code: string, analysisType: AnalysisType): Promise<string | TestCase[] | { error: string }> => {
  if (!code.trim()) {
    return 'Please enter some code to analyze.';
  }

  const prompt = `${PROMPTS[analysisType]}\n\n---\n\nCODE:\n\`\`\`\n${code}\n\`\`\``;
  const isJsonOutput = analysisType === AnalysisType.PREDICT_TEST_CASES;

  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: 'gemini-2.5-flash-preview-04-17',
      contents: prompt,
      config: {
        ...(isJsonOutput && { responseMimeType: 'application/json' }),
        temperature: 0.2,
        topP: 0.95,
        topK: 64,
      },
    });

    const textResponse = response.text;
    if (analysisType === AnalysisType.PREDICT_TEST_CASES) {
      return parseTestCases(textResponse);
    }
    return textResponse;

  } catch (error) {
    console.error("Gemini API call failed:", error);
    if (error instanceof Error) {
        return { error: `An error occurred while analyzing the code: ${error.message}` };
    }
    return { error: 'An unknown error occurred while analyzing the code.' };
  }
};


// --- MESSAGE HANDLING ---
chrome.runtime.onMessage.addListener((message: Message, sender, sendResponse) => {
  if (message.type === 'ANALYZE_CODE') {
    const { code, analysisType } = message.payload;
    analyzeCode(code, analysisType)
      .then(sendResponse)
      .catch(error => sendResponse({ error: error.message }));
    return true; // Indicates an asynchronous response.
  }
});
