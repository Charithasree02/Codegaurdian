
import { defineConfig, loadEnv } from 'vite';
import react from '@vitejs/plugin-react';
import { resolve, dirname } from 'path';
import { fileURLToPath } from 'url';
import process from 'process';

// In ES modules, __dirname is not available by default. This is the workaround.
const __dirname = dirname(fileURLToPath(import.meta.url));

// https://vitejs.dev/config/
export default defineConfig(({ mode }) => {
  // Load .env file based on the current mode. process.cwd() is used to find the .env file at the project root.
  const env = loadEnv(mode, process.cwd(), '');

  return {
    plugins: [react()],
    // Define process.env for use in the app, compliant with Gemini guidelines
    define: {
      'process.env.API_KEY': JSON.stringify(env.VITE_API_KEY)
    },
    publicDir: 'public',
    build: {
      outDir: 'dist',
      emptyOutDir: true,
      sourcemap: process.env.NODE_ENV === 'development' ? 'inline' : false,
      rollupOptions: {
        input: {
          popup: resolve(__dirname, 'src/popup.html'),
          content: resolve(__dirname, 'src/content.tsx'),
          background: resolve(__dirname, 'src/background.ts'),
        },
        output: {
          entryFileNames: '[name].js',
          // Preserve asset names for manifest resources like icons
          assetFileNames: (assetInfo) => {
            return assetInfo.name?.endsWith('.css') 
              ? 'assets/[name].[hash][extname]' 
              : 'assets/[name][extname]';
          },
        },
      },
      chunkSizeWarningLimit: 1000,
    },
  };
});
