
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import { AnalysisType, TestCase } from '../types';
import { PROMPTS } from '../constants';

if (!process.env.API_KEY) {
  // In a real extension, this would be handled more gracefully.
  // For this context, we assume the key is available via Vite's .env loading.
  console.warn("API_KEY environment variable not set. Using a placeholder for local dev.");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || "YOUR_API_KEY_FOR_LOCAL_DEV_ONLY" });

const parseTestCases = (jsonString: string): TestCase[] => {
  let cleanJsonString = jsonString.trim();
  const fenceRegex = /^```(?:json)?\s*\n?(.*?)\n?\s*```$/s;
  const match = cleanJsonString.match(fenceRegex);
  if (match && match[1]) {
    cleanJsonString = match[1].trim();
  }

  try {
    const data = JSON.parse(cleanJsonString);
    if (Array.isArray(data)) {
      return data.filter(item => typeof item === 'object' && item !== null && 'input' in item && 'expectedOutput' in item);
    }
    console.warn("Parsed JSON is not an array:", data);
    return [{ input: 'Parsing Error', expectedOutput: 'Received valid JSON, but it was not an array of test cases.', description: cleanJsonString }];
  } catch (error) {
    console.error("Failed to parse JSON response:", error);
    return [{ input: 'Error', expectedOutput: 'Failed to parse JSON from AI.', description: jsonString }];
  }
};

export const analyzeCode = async (code: string, analysisType: AnalysisType): Promise<string | TestCase[]> => {
  if (!code.trim()) {
    return 'Please enter some code to analyze.';
  }

  const prompt = `${PROMPTS[analysisType]}\n\n---\n\nCODE:\n\`\`\`\n${code}\n\`\`\``;
  const isJsonOutput = analysisType === AnalysisType.PREDICT_TEST_CASES;

  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: 'gemini-2.5-flash-preview-04-17',
      contents: prompt,
      config: {
        ...(isJsonOutput && { responseMimeType: 'application/json' }),
        temperature: 0.2,
        topP: 0.95,
        topK: 64,
      },
    });

    const textResponse = response.text;

    if (analysisType === AnalysisType.PREDICT_TEST_CASES) {
      return parseTestCases(textResponse);
    }
    
    return textResponse;

  } catch (error) {
    console.error("Gemini API call failed:", error);
    if (error instanceof Error) {
        return `An error occurred while analyzing the code: ${error.message}`;
    }
    return 'An unknown error occurred while analyzing the code.';
  }
};
