
declare const chrome: any;

import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import { AnalysisType, TestCase, Message, AnalysisResponse } from './types';
import { PROMPTS } from './constants';

let ai: GoogleGenAI | null = null;
let initError: Error | null = null;

// --- INITIALIZATION ---
try {
  // API key is injected by the Vite build process via vite.config.ts
  const apiKey = process.env.API_KEY;
  if (!apiKey) {
    throw new Error("API_KEY is not defined. Please ensure the VITE_API_KEY environment variable is set during the build process.");
  }
  ai = new GoogleGenAI({ apiKey });
} catch (error) {
  console.error("Fatal Error: Failed to initialize GoogleGenAI. The extension will not work.", error);
  initError = error instanceof Error ? error : new Error('An unknown error occurred during initialization.');
}

// --- CONTEXT MENU SETUP ---
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: "code-guardian-analyze",
    title: "Analyze with Code Guardian",
    contexts: ["selection"],
  });
});

chrome.contextMenus.onClicked.addListener((info: any, tab?: any) => {
  if (info.menuItemId === "code-guardian-analyze" && info.selectionText && tab?.id) {
    chrome.tabs.sendMessage(tab.id, {
      type: 'TOGGLE_PANEL',
      payload: { code: info.selectionText },
    });
  }
});

// --- MESSAGE HANDLING ---
chrome.runtime.onMessage.addListener((message: Message, sender: any, sendResponse: (response?: any) => void) => {
  if (message.type === 'ANALYZE_CODE') {
    analyzeCode(message.payload.code, message.payload.analysisType)
      .then(sendResponse)
      .catch(error => sendResponse({ error: error.message })); // Safety net for unexpected promise rejections
    return true; // Indicates an asynchronous response.
  }
  return false; // For other message types
});


// --- API LOGIC ---

const parseTestCases = (jsonString: string): TestCase[] => {
  let cleanJsonString = jsonString.trim();
  const fenceRegex = /^```(?:json)?\s*\n?(.*?)\n?\s*```$/s;
  const match = cleanJsonString.match(fenceRegex);
  if (match && match[1]) {
    cleanJsonString = match[1].trim();
  }
  try {
    const data = JSON.parse(cleanJsonString);
    if (Array.isArray(data)) {
      return data.filter(item => typeof item === 'object' && item !== null && 'input' in item && 'expectedOutput' in item);
    }
    return [{ input: 'Parsing Error', expectedOutput: 'Received valid JSON, but it was not an array of test cases.', description: cleanJsonString }];
  } catch (error) {
    console.error("Failed to parse JSON response:", error);
    return [{ input: 'Error', expectedOutput: 'Failed to parse JSON from AI.', description: jsonString }];
  }
};

const analyzeCode = async (code: string, analysisType: AnalysisType): Promise<AnalysisResponse> => {
  if (initError) {
    return { error: `Gemini AI service is not available: ${initError.message}` };
  }
  if (!ai) {
     return { error: "Gemini AI service could not be initialized. Check service worker logs for details." };
  }
  if (!code.trim()) {
    return { error: 'Please provide some code to analyze.' };
  }

  const prompt = `${PROMPTS[analysisType]}\n\n---\n\nCODE:\n\`\`\`\n${code}\n\`\`\``;
  const isJsonOutput = analysisType === AnalysisType.PREDICT_TEST_CASES;

  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: 'gemini-2.5-flash-preview-04-17',
      contents: prompt,
      config: {
        ...(isJsonOutput && { responseMimeType: 'application/json' }),
        temperature: 0.2,
        topP: 0.95,
        topK: 64,
      },
    });

    const textResponse = response.text;

    if (textResponse === undefined) {
      return { error: 'Received an empty or invalid response from the AI model.' };
    }
    
    if (analysisType === AnalysisType.PREDICT_TEST_CASES) {
      return { content: parseTestCases(textResponse) };
    }
    return { content: textResponse };
  } catch (error) {
    console.error("Gemini API call failed:", error);
    if (error instanceof Error) {
        if (error.message.includes('API key not valid')) {
            return { error: "The provided API Key is not valid. Please check the key and rebuild the extension."};
        }
        return { error: `An error occurred during analysis: ${error.message}` };
    }
    return { error: 'An unknown error occurred while analyzing the code.' };
  }
};
