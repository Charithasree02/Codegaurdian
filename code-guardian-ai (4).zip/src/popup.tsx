
import React from 'react';
import ReactDOM from 'react-dom/client';
import { LogoIcon } from './components/icons';
import './index.css';

const Popup: React.FC = () => {
    return (
        <div className="bg-gray-900 text-white p-6 flex flex-col items-center text-center">
            <LogoIcon className="w-16 h-16 text-blue-500 mb-4" />
            <h1 className="text-xl font-bold text-gray-100">Code Guardian AI</h1>
            <p className="text-gray-400 mt-2 text-sm">
                To use the assistant, simply highlight any code snippet on a webpage,
                right-click, and select "Analyze with Code Guardian" from the menu.
            </p>
        </div>
    );
};

const rootElement = document.getElementById('root');
if (!rootElement) {
  throw new Error("Could not find root element to mount to");
}

const root = ReactDOM.createRoot(rootElement);
root.render(
  <React.StrictMode>
    <Popup />
  </React.StrictMode>
);
