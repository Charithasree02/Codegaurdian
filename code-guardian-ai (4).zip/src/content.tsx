
declare const chrome: any;

import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import { Message } from './types';
import css from './index.css?inline';

const SIDEPANEL_ID = 'code-guardian-sidepanel';
let sidePanel: HTMLElement | null = null;
let sidePanelRoot: ReactDOM.Root | null = null;

const createSidePanel = (initialCode: string) => {
    if (sidePanel) return;

    sidePanel = document.createElement('div');
    sidePanel.id = SIDEPANEL_ID;
    sidePanel.style.cssText = `
        position: fixed;
        top: 0;
        right: 0;
        width: 500px;
        max-width: 90vw;
        height: 100vh;
        z-index: 2147483647;
        border-left: 1px solid #374151;
        transform: translateX(100%);
        transition: transform 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        box-shadow: -10px 0 20px -5px rgba(0,0,0,0.2);
        background-color: #111827;
    `;
    document.body.appendChild(sidePanel);

    const shadowRoot = sidePanel.attachShadow({ mode: 'open' });
    
    const styleSheet = document.createElement('style');
    styleSheet.textContent = css;
    shadowRoot.appendChild(styleSheet);

    const appContainer = document.createElement('div');
    appContainer.style.height = '100vh';
    shadowRoot.appendChild(appContainer);
    
    const onClose = () => {
        if (sidePanel) {
            sidePanel.style.transform = 'translateX(100%)';
            setTimeout(() => {
                sidePanelRoot?.unmount();
                sidePanel?.remove();
                sidePanel = null;
                sidePanelRoot = null;
            }, 300);
        }
    };

    sidePanelRoot = ReactDOM.createRoot(appContainer);
    sidePanelRoot.render(
      <React.StrictMode>
        <App initialCode={initialCode} onClose={onClose} />
      </React.StrictMode>
    );

    requestAnimationFrame(() => {
      if (sidePanel) {
        sidePanel.style.transform = 'translateX(0)';
      }
    });
};

const togglePanel = (code: string) => {
    if (sidePanel) {
        const appElement = sidePanel.shadowRoot?.querySelector('#code-guardian-app');
        if (appElement instanceof HTMLElement) {
          const event = new CustomEvent('updateCode', { detail: code });
          appElement.dispatchEvent(event);
        }
    } else {
        createSidePanel(code);
    }
};

chrome.runtime.onMessage.addListener((message: Message, sender: any, sendResponse: (response?: any) => void) => {
  if (message.type === 'TOGGLE_PANEL' && message.payload?.code) {
    togglePanel(message.payload.code);
    sendResponse({ success: true });
  }
  return true;
});
