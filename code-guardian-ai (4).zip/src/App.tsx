
declare const chrome: any;

import React, { useState, useCallback, useEffect, useRef } from 'react';
import { AnalysisType, AnalysisResult, Message, AnalysisResponse } from './types';
import ActionButton from './components/ActionButton';
import OutputDisplay from './components/OutputDisplay';
import { BugIcon, ClockIcon, SparklesIcon, BeakerIcon, LogoIcon, CloseIcon } from './components/icons';
import { analyzeCode as analyzeCodeLocally } from './services/geminiService';

interface AppProps {
  initialCode: string;
  onClose: () => void;
}

const App: React.FC<AppProps> = ({ initialCode, onClose }) => {
  const [code, setCode] = useState<string>(initialCode);
  const [activeAnalysis, setActiveAnalysis] = useState<AnalysisType | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const appRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleUpdateCode = (event: Event) => {
      const customEvent = event as CustomEvent<string>;
      setCode(customEvent.detail);
      setResult(null);
      setError(null);
      setActiveAnalysis(null);
    };

    const currentAppRef = appRef.current;
    currentAppRef?.addEventListener('updateCode', handleUpdateCode);

    return () => {
      currentAppRef?.removeEventListener('updateCode', handleUpdateCode);
    };
  }, []);

  const handleAnalysis = useCallback(async (analysisType: AnalysisType) => {
    if (loading) return;
    if (!code.trim()) {
      setError("Please enter some code to analyze.");
      return;
    }
    
    setError(null);
    setLoading(true);
    setResult(null);
    setActiveAnalysis(analysisType);

    try {
      let response: AnalysisResponse;
      
      if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage) {
        const message: Message = {
          type: 'ANALYZE_CODE',
          payload: { code, analysisType }
        };
        response = await chrome.runtime.sendMessage(message);
      } else {
        console.warn("Chrome runtime not available. Using direct API call for development.");
        const localResponse = await analyzeCodeLocally(code, analysisType);
        if (typeof localResponse === 'string' && localResponse.startsWith("Error:")) {
            response = { error: localResponse };
        } else {
            response = { content: localResponse };
        }
      }

      if (response?.error) {
        setError(response.error);
        setResult(null);
      } else if (response?.content !== undefined) {
        setResult({ type: analysisType, content: response.content });
        setError(null);
      } else {
        setError("Received an unexpected or empty response from the analysis service.");
        setResult(null);
      }
    } catch (e: unknown) {
      const errorMessage = e instanceof Error ? e.message : 'An unexpected error occurred.';
       if (errorMessage.includes('Receiving end does not exist')) {
        setError("Connection to background service failed. The extension may have crashed or is reloading. Check the service worker logs, ensure your API key is correct, and try again.");
       } else {
        setError(`An unexpected error occurred during analysis: ${errorMessage}`);
       }
      setResult(null);
    } finally {
      setLoading(false);
    }
  }, [code, loading]);

  return (
    <div id="code-guardian-app" ref={appRef} className="h-full bg-gray-900 text-white font-sans flex flex-col">
      <header className="p-3 border-b border-gray-700 bg-gray-800/80 backdrop-blur-sm flex items-center justify-between flex-shrink-0">
        <div className="flex items-center gap-3">
          <LogoIcon className="w-7 h-7 text-blue-500" />
          <h1 className="text-xl font-bold text-gray-100">Code Guardian</h1>
        </div>
        <button
          onClick={onClose}
          className="p-2 rounded-full text-gray-400 hover:bg-gray-700 hover:text-white transition-colors focus:outline-none focus:ring-2 focus:ring-blue-500"
          aria-label="Close panel"
        >
          <CloseIcon className="w-5 h-5" />
        </button>
      </header>
      
      <main className="flex flex-col flex-grow min-h-0">
        <div className="flex flex-col flex-1 min-h-0">
          <div className="flex-grow flex flex-col bg-gray-800 overflow-hidden">
            <textarea
              value={code}
              onChange={(e) => setCode(e.target.value)}
              placeholder="Paste your code here..."
              className="w-full h-full p-4 bg-gray-800 text-gray-300 font-mono text-sm resize-none focus:outline-none flex-grow"
              spellCheck="false"
              aria-label="Code Input Area"
            />
          </div>
          <div className="grid grid-cols-2 gap-3 p-3 border-y border-gray-700">
             <ActionButton onClick={() => handleAnalysis(AnalysisType.DETECT_ERRORS)} isActive={activeAnalysis === AnalysisType.DETECT_ERRORS} Icon={BugIcon} disabled={loading}>Detect Errors</ActionButton>
             <ActionButton onClick={() => handleAnalysis(AnalysisType.ANALYZE_COMPLEXITY)} isActive={activeAnalysis === AnalysisType.ANALYZE_COMPLEXITY} Icon={ClockIcon} disabled={loading}>Analyze TLE</ActionButton>
             <ActionButton onClick={() => handleAnalysis(AnalysisType.EXPLAIN_CODE)} isActive={activeAnalysis === AnalysisType.EXPLAIN_CODE} Icon={SparklesIcon} disabled={loading}>Explain Code</ActionButton>
             <ActionButton onClick={() => handleAnalysis(AnalysisType.PREDICT_TEST_CASES)} isActive={activeAnalysis === AnalysisType.PREDICT_TEST_CASES} Icon={BeakerIcon} disabled={loading}>Test Cases</ActionButton>
          </div>
        </div>

        <div className="bg-gray-800/50 flex-1 overflow-y-auto min-h-0">
          <OutputDisplay loading={loading} error={error} result={result} />
        </div>
      </main>
    </div>
  );
};

export default App;
