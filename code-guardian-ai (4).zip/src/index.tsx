
import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import './index.css';

const rootElement = document.getElementById('root');
if (!rootElement) {
  throw new Error("Could not find root element to mount to");
}

const root = ReactDOM.createRoot(rootElement);
root.render(
  <React.StrictMode>
    <App initialCode="/* Welcome to Code Guardian! Paste your code here to get started, or highlight code on any webpage, right-click, and select 'Analyze with Code Guardian'. */" onClose={() => { console.log("Close button clicked in dev mode."); }} />
  </React.StrictMode>
);
