
export enum AnalysisType {
  DETECT_ERRORS = 'DETECT_ERRORS',
  ANALYZE_COMPLEXITY = 'ANALYZE_COMPLEXITY',
  EXPLAIN_CODE = 'EXPLAIN_CODE',
  PREDICT_TEST_CASES = 'PREDICT_TEST_CASES',
}

export interface TestCase {
  input: string;
  expectedOutput: string;
  description?: string;
}

export type AnalysisResult = {
  type: AnalysisType;
  content: string | TestCase[];
};

export type Message = {
  type: 'TOGGLE_PANEL' | 'ANALYZE_CODE';
  payload?: any;
};

// Response from background script to app
export type AnalysisResponse = {
  content?: string | TestCase[];
  error?: string;
}
