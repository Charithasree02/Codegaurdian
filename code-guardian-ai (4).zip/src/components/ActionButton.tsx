
import React from 'react';

interface ActionButtonProps {
  onClick: () => void;
  isActive: boolean;
  children: React.ReactNode;
  Icon: React.ElementType;
  disabled?: boolean;
}

const ActionButton: React.FC<ActionButtonProps> = ({ onClick, isActive, children, Icon, disabled }) => {
  const baseClasses = "flex items-center justify-center w-full p-3 rounded-lg text-sm font-semibold transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-900";
  const activeClasses = "bg-blue-600 text-white shadow-lg ring-blue-500";
  const inactiveClasses = "bg-gray-700 text-gray-300 hover:bg-gray-600 hover:text-white focus:ring-blue-500";
  const disabledClasses = "bg-gray-700/50 text-gray-500 cursor-not-allowed";

  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className={`${baseClasses} ${disabled ? disabledClasses : (isActive ? activeClasses : inactiveClasses)}`}
      aria-pressed={isActive}
    >
      <Icon className="w-5 h-5 mr-3 flex-shrink-0" aria-hidden="true" />
      <span className="truncate">{children}</span>
    </button>
  );
};

export default ActionButton;
