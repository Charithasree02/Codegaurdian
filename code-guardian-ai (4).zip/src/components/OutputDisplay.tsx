
import React from 'react';
import { AnalysisResult, TestCase, AnalysisType } from '../types';
import { LogoIcon } from './icons';

const LoadingSpinner: React.FC = () => (
  <div className="flex justify-center items-center h-full p-6">
    <div className="flex flex-col items-center gap-4">
      <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
      <p className="text-gray-400">Guardian is thinking...</p>
    </div>
  </div>
);

const WelcomeMessage: React.FC = () => (
  <div className="text-center text-gray-500 flex flex-col items-center justify-center h-full p-6">
    <LogoIcon className="w-24 h-24 text-gray-700" />
    <h3 className="text-xl font-semibold mt-4 text-gray-300">Analysis Output</h3>
    <p className="mt-2 max-w-sm">The results of your code analysis will appear here.</p>
  </div>
);

const TestCasesTable: React.FC<{ cases: TestCase[] }> = ({ cases }) => (
    <div className="overflow-x-auto p-1">
        <table className="min-w-full divide-y divide-gray-700">
            <thead className="bg-gray-800 sticky top-0 z-10">
                <tr>
                    <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">Input</th>
                    <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">Expected Output</th>
                    <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">Description</th>
                </tr>
            </thead>
            <tbody className="bg-gray-900/50 divide-y divide-gray-700">
                {cases.map((testCase, index) => (
                    <tr key={index} className="hover:bg-gray-800/70 transition-colors">
                        <td className="px-4 py-4 align-top"><pre className="w-full whitespace-pre-wrap font-mono text-sm text-gray-200">{testCase.input}</pre></td>
                        <td className="px-4 py-4 align-top"><pre className="w-full whitespace-pre-wrap font-mono text-sm text-green-400">{testCase.expectedOutput}</pre></td>
                        <td className="px-4 py-4 whitespace-pre-wrap text-sm text-gray-400 align-top">{testCase.description}</td>
                    </tr>
                ))}
            </tbody>
        </table>
    </div>
);

const FormattedText: React.FC<{ text: string }> = ({ text }) => {
  return (
    <div className="p-4">
        <pre className="whitespace-pre-wrap text-gray-300 text-sm leading-relaxed font-sans">
        {text}
        </pre>
    </div>
  );
};


interface OutputDisplayProps {
  result: AnalysisResult | null;
  loading: boolean;
  error: string | null;
}

const OutputDisplay: React.FC<OutputDisplayProps> = ({ result, loading, error }) => {
  if (loading) return <LoadingSpinner />;
  if (error) return <div className="p-4 m-4 text-red-300 bg-red-900/50 rounded-lg whitespace-pre-wrap font-mono text-sm" role="alert">{error}</div>;
  if (!result) return <WelcomeMessage />;

  const renderContent = () => {
    if (typeof result.content === 'string') {
        return <FormattedText text={result.content} />;
    }
    if (result.type === AnalysisType.PREDICT_TEST_CASES && Array.isArray(result.content)) {
        return <TestCasesTable cases={result.content as TestCase[]} />;
    }
    return <FormattedText text="Received an unexpected data format." />;
  };

  return <div className="h-full">{renderContent()}</div>;
};

export default OutputDisplay;
