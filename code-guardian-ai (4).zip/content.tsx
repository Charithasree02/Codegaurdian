declare const chrome: any;

import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './src/App';
import { Message } from './src/types';

const SIDEPANEL_ID = 'code-guardian-sidepanel';
let sidePanel: HTMLElement | null = null;
let sidePanelRoot: ReactDOM.Root | null = null;

const createSidePanel = (initialCode: string) => {
    sidePanel = document.createElement('div');
    sidePanel.id = SIDEPANEL_ID;
    sidePanel.style.cssText = `
        position: fixed;
        top: 0;
        right: 0;
        width: 500px;
        max-width: 90vw;
        height: 100vh;
        z-index: 2147483647;
        border-left: 1px solid #374151;
        transform: translateX(100%);
        transition: transform 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        box-shadow: -10px 0 20px -5px rgba(0,0,0,0.2);
    `;
    document.body.appendChild(sidePanel);

    const shadowRoot = sidePanel.attachShadow({ mode: 'open' });
    
    // Inject Tailwind CSS via a constructed style tag which is more reliable in Shadow DOM
    const styleSheet = document.createElement('style');
    // A basic set of Tailwind's preflight styles + custom scrollbars
    // NOTE: In a real build, this CSS should be imported and injected by Vite.
    // For simplicity here, we use a CDN link inside the shadow DOM.
    // This is less ideal than a proper build pipeline but works for this structure.
    const tailwindCssUrl = 'https://cdn.tailwindcss.com';
    styleSheet.textContent = `
        @import url('${tailwindCssUrl}');
        /* Custom scrollbar styles */
        ::-webkit-scrollbar { width: 8px; height: 8px; }
        ::-webkit-scrollbar-track { background: #1f2937; }
        ::-webkit-scrollbar-thumb { background-color: #4b5563; border-radius: 4px; border: 2px solid #1f2937; }
        ::-webkit-scrollbar-thumb:hover { background-color: #6b7280; }
    `;
    shadowRoot.appendChild(styleSheet);

    const appContainer = document.createElement('div');
    appContainer.style.height = '100vh'; // Ensure the app container fills the shadow host
    shadowRoot.appendChild(appContainer);
    
    const onClose = () => {
        if (sidePanel) {
            sidePanel.style.transform = 'translateX(100%)';
            setTimeout(() => {
                sidePanelRoot?.unmount();
                sidePanel?.remove();
                sidePanel = null;
                sidePanelRoot = null;
            }, 300);
        }
    };

    sidePanelRoot = ReactDOM.createRoot(appContainer);
    sidePanelRoot.render(
      <React.StrictMode>
        <App initialCode={initialCode} onClose={onClose} />
      </React.StrictMode>
    );

    // Animate in
    requestAnimationFrame(() => {
      if (sidePanel) {
        sidePanel.style.transform = 'translateX(0)';
      }
    });
};

const togglePanel = (code: string) => {
    if (sidePanel) {
        const appElement = sidePanel.shadowRoot?.querySelector('#code-guardian-app');
        if (appElement instanceof HTMLElement) {
          // Send event to existing App to update code
          const event = new CustomEvent('updateCode', { detail: code });
          appElement.dispatchEvent(event);
        }
    } else {
        createSidePanel(code);
    }
};

chrome.runtime.onMessage.addListener((message: Message, sender, sendResponse) => {
  if (message.type === 'TOGGLE_PANEL') {
    togglePanel(message.payload.code);
    sendResponse({ success: true });
  }
  return true; // Keep message channel open for async response
});
